import { useState, type FormEvent } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { geocode } from "@/lib/geocode";
import type { DealType, Listing } from "@/lib/listings";
import { usePosts } from "@/lib/posts";

const PLACEHOLDER =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 200"><rect width="300" height="200" fill="#e7f3ec"/><path d="M60 120l90-60 90 60v50H60z" fill="#0e6b4f" opacity=".25"/></svg>',
  );

const EMPTY = {
  title: "",
  type: "rent" as DealType,
  currency: "$",
  price: "",
  address: "",
  city: "",
  beds: "",
  baths: "",
  area: "",
  contact: "",
  blurb: "",
};

const input = "h-11 w-full rounded-xl bg-paper px-3 text-base outline-none focus-visible:ring-2 focus-visible:ring-grove";

function readPhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, 800 / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext("2d")?.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.7));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("bad image"));
    };
    img.src = url;
  });
}

export function PostForm({ open, onClose }: { open: boolean; onClose: () => void }) {
  const add = usePosts((s) => s.add);
  const [f, setF] = useState(EMPTY);
  const [photo, setPhoto] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (key: keyof typeof EMPTY, value: string) => setF((cur) => ({ ...cur, [key]: value }));

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    const price = Number(f.price);
    if (!f.title.trim() || !f.address.trim() || !Number.isFinite(price) || price <= 0) {
      setError("Title, address and a valid price are required.");
      return;
    }
    setBusy(true);
    try {
      const place = await geocode(`${f.address}, ${f.city}`);
      if (!place) {
        setError("Address not found on the map. Check the address and city.");
        return;
      }
      const post: Listing = {
        id: `post-${Date.now()}`,
        title: f.title.trim(),
        price,
        type: f.type,
        address: f.address.trim(),
        neighborhood: "",
        city: f.city.trim() || f.address.trim(),
        region: "",
        beds: Number(f.beds) || 0,
        baths: Number(f.baths) || 0,
        areaSqft: Number(f.area) || 0,
        lat: place.lat,
        lng: place.lng,
        image: photo || PLACEHOLDER,
        source: "My post",
        sourceUrl: "",
        blurb: f.blurb.trim() || "Posted from this device.",
        currency: f.currency.trim() || "$",
        contact: f.contact.trim() || undefined,
        mine: true,
      };
      add(post);
      setF(EMPTY);
      setPhoto("");
      onClose();
    } catch {
      setError("Could not reach the map service. Check your internet.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog.Root open={open} onOpenChange={(next) => !next && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/45" />
        <Dialog.Content className="fixed inset-x-0 bottom-0 z-50 max-h-[92dvh] overflow-y-auto rounded-t-3xl bg-card p-5 shadow-card focus:outline-none md:inset-auto md:top-1/2 md:left-1/2 md:w-[min(32rem,calc(100%-2rem))] md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-3xl">
          <div className="mb-3 flex items-start justify-between gap-3">
            <div>
              <Dialog.Title className="font-display text-2xl">Post a home</Dialog.Title>
              <Dialog.Description className="text-sm text-muted">
                Saved on this device. Searching its address shows it on the map.
              </Dialog.Description>
            </div>
            <Dialog.Close aria-label="Close" className="grid size-11 shrink-0 place-items-center rounded-full bg-paper">
              <X className="size-5" />
            </Dialog.Close>
          </div>
          <form onSubmit={submit} className="flex flex-col gap-3">
            <input className={input} placeholder="Title (e.g. 3 bed house)" value={f.title} onChange={(e) => set("title", e.target.value)} />
            <div className="grid grid-cols-3 gap-2">
              <select className={input} value={f.type} onChange={(e) => set("type", e.target.value)} aria-label="Rent or sale">
                <option value="rent">Rent</option>
                <option value="sale">Sale</option>
              </select>
              <input className={input} placeholder="Currency" value={f.currency} onChange={(e) => set("currency", e.target.value)} aria-label="Currency" />
              <input className={input} inputMode="numeric" placeholder="Price" value={f.price} onChange={(e) => set("price", e.target.value)} />
            </div>
            <input className={input} placeholder="Full address" value={f.address} onChange={(e) => set("address", e.target.value)} />
            <input className={input} placeholder="City" value={f.city} onChange={(e) => set("city", e.target.value)} />
            <div className="grid grid-cols-3 gap-2">
              <input className={input} inputMode="numeric" placeholder="Beds" value={f.beds} onChange={(e) => set("beds", e.target.value)} />
              <input className={input} inputMode="decimal" placeholder="Baths" value={f.baths} onChange={(e) => set("baths", e.target.value)} />
              <input className={input} inputMode="numeric" placeholder="Sq ft" value={f.area} onChange={(e) => set("area", e.target.value)} />
            </div>
            <input className={input} inputMode="tel" placeholder="Contact phone (optional)" value={f.contact} onChange={(e) => set("contact", e.target.value)} />
            <textarea className={input + " h-24 py-2"} placeholder="Description (optional)" value={f.blurb} onChange={(e) => set("blurb", e.target.value)} />
            <label className="text-sm text-muted">
              Photo (optional)
              <input
                type="file"
                accept="image/*"
                className="mt-1 block w-full text-sm"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void readPhoto(file).then(setPhoto).catch(() => setError("Could not read that photo."));
                }}
              />
            </label>
            {photo ? <img src={photo} alt="" className="aspect-3/2 w-full rounded-xl object-cover" /> : null}
            {error ? <p className="text-sm text-red-700">{error}</p> : null}
            <button type="submit" disabled={busy} className="min-h-11 rounded-full bg-grove px-4 text-sm font-medium text-on-grove disabled:opacity-60">
              {busy ? "Finding address…" : "Publish post"}
            </button>
          </form>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
