import { Heart, MapPin, ArrowUpRight } from "lucide-react";
import { formatBaths, formatPrice, placeLine, type Listing } from "@/lib/listings";

type Props = {
  listing: Listing;
  selected: boolean;
  saved: boolean;
  onOpen: () => void;
  onSave: () => void;
};

export function PropertyCard({ listing, selected, saved, onOpen, onSave }: Props) {
  return (
    <article
      id={`listing-${listing.id}`}
      className={
        "overflow-hidden rounded-2xl bg-card shadow-card transition-[box-shadow] duration-200 " +
        (selected ? "ring-2 ring-grove" : "hover:shadow-card-hover")
      }
    >
      <div className="relative">
        <button type="button" onClick={onOpen} className="block w-full text-left">
          <img
            src={listing.image}
            alt={listing.title}
            className="aspect-3/2 w-full object-cover outline outline-1 -outline-offset-1 outline-ink/10"
          />
          <span className="absolute top-3 left-3 rounded-full bg-card px-3 py-1 text-xs font-medium tracking-wide text-grove-deep uppercase">
            {listing.type === "rent" ? "For rent" : "For sale"}
          </span>
          <span className="absolute bottom-3 left-3 rounded-full bg-ink/80 px-3 py-1 text-xs font-medium text-on-grove">
            {listing.source}
          </span>
        </button>
        <button
          type="button"
          onClick={onSave}
          aria-pressed={saved}
          aria-label={saved ? `Remove ${listing.title} from saved` : `Save ${listing.title}`}
          className="absolute top-2 right-2 grid size-11 place-items-center rounded-full bg-card shadow-card"
        >
          <Heart className={saved ? "size-5 fill-grove text-grove" : "size-5 text-ink"} strokeWidth={1.75} />
        </button>
      </div>

      <div className="flex flex-col gap-3 p-4">
        <button type="button" onClick={onOpen} className="flex flex-col gap-1 text-left">
          <p className="font-display text-2xl leading-none text-ink tabular-nums">{formatPrice(listing)}</p>
          <h2 className="font-display text-lg leading-snug font-medium text-ink">{listing.title}</h2>
          <p className="flex items-center gap-1.5 text-sm text-muted">
            <MapPin className="size-4 shrink-0 text-grove" strokeWidth={1.75} aria-hidden="true" />
            <span>{placeLine(listing)}</span>
          </p>
          <p className="text-sm text-muted tabular-nums">
            {listing.beds} bd · {formatBaths(listing.baths)} ba · {listing.areaSqft.toLocaleString("en-US")} sq ft
          </p>
        </button>
{listing.sourceUrl ? (
        <a
          href={listing.sourceUrl}
          target="_blank"
          rel="noreferrer noopener"
          className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-full bg-grove px-4 text-sm font-medium text-on-grove transition-colors duration-200 hover:bg-grove-deep"
        >
          View original listing
          <ArrowUpRight className="size-4" strokeWidth={1.75} aria-hidden="true" />
        </a>
) : null}
      </div>
    </article>
  );
}
