import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Heart, Leaf, Map as MapIcon, MapPin, Plus, Rows3, Search, SlidersHorizontal, X } from "lucide-react";
import { ListingDetail } from "@/components/listing-detail";
import { ListingMap } from "@/components/listing-map";
import { PostForm } from "@/components/post-form";
import { PropertyCard } from "@/components/property-card";
import { useFavorites } from "@/lib/favorites";
import { geocode, type Place } from "@/lib/geocode";
import { usePosts } from "@/lib/posts";
import { AREA_PRESETS, PRICE_PRESETS, presetById } from "@/lib/filters";
import { LISTINGS, queryListings, toPayload, type DealType } from "@/lib/listings";


type DealFilter = "all" | DealType;
type MobilePane = "list" | "map";

export default function App() {
  const savedIds = useFavorites((state) => state.ids);
  const toggleSaved = useFavorites((state) => state.toggle);

  const [draft, setDraft] = useState("");
  const [location, setLocation] = useState("");
  const [deal, setDeal] = useState<DealFilter>("all");
  const [priceId, setPriceId] = useState("any");
  const [areaId, setAreaId] = useState("any");
  const [panel, setPanel] = useState<null | "price" | "area">(null);
  const [savedOnly, setSavedOnly] = useState(false);
  const [mobilePane, setMobilePane] = useState<MobilePane>("list");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [place, setPlace] = useState<Place | null>(null);
  const [placeMsg, setPlaceMsg] = useState("");
  const [searching, setSearching] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const posts = usePosts((state) => state.posts);
  const removePost = usePosts((state) => state.remove);

  const price = presetById(PRICE_PRESETS, priceId);
  const area = presetById(AREA_PRESETS, areaId);
  const type: DealType | "" = price.type ?? (deal === "all" ? "" : deal);

  useEffect(() => {
    const timer = setTimeout(() => setLocation(draft.trim()), 280);
    return () => clearTimeout(timer);
  }, [draft]);

  const pool = useMemo(() => [...posts, ...LISTINGS], [posts]);
  const payload = useMemo(
    () =>
      toPayload(
        queryListings(
          {
            location,
            type,
            priceMin: price.min,
            priceMax: price.max,
            areaMin: area.min,
            areaMax: area.max,
            near: place ? { lat: place.lat, lng: place.lng, km: 30 } : undefined,
          },
          pool,
        ),
        false,
      ),
    [area.max, area.min, location, place, pool, price.max, price.min, type],
  );

  async function runSearch() {
    const q = draft.trim();
    setLocation(q);
    setPlaceMsg("");
    if (!q) {
      setPlace(null);
      return;
    }
    setSearching(true);
    try {
      const found = await geocode(q);
      setPlace(found);
      if (!found) setPlaceMsg("Address not found on the map. Try adding the city.");
    } catch {
      setPlace(null);
      setPlaceMsg("Could not look up the address. Check your internet.");
    } finally {
      setSearching(false);
    }
  }

  // Android back button: close sheet/panel, then map, then exit.
  useEffect(() => {
    let cancelled = false;
    let handle: { remove: () => Promise<void> } | undefined;
    void import("@capacitor/app").then(async ({ App: CapApp }) => {
      const h = await CapApp.addListener("backButton", () => {
        if (formOpen) setFormOpen(false);
        else if (detailId) setDetailId(null);
        else if (panel) setPanel(null);
        else if (mobilePane === "map") setMobilePane("list");
        else void CapApp.exitApp();
      });
      if (cancelled) void h.remove();
      else handle = h;
    });
    return () => {
      cancelled = true;
      void handle?.remove();
    };
  }, [detailId, formOpen, panel, mobilePane]);

  const visible = useMemo(() => {
    if (!savedOnly) return payload.listings;
    const saved = new Set(savedIds);
    return payload.listings.filter((listing) => saved.has(listing.id));
  }, [payload.listings, savedIds, savedOnly]);

  useEffect(() => {
    if (selectedId && !visible.some((listing) => listing.id === selectedId)) {
      setSelectedId(null);
    }
  }, [selectedId, visible]);

  useEffect(() => {
    if (!selectedId) return;
    document.getElementById(`listing-${selectedId}`)?.scrollIntoView({ block: "nearest" });
  }, [selectedId]);

  const detail =
    [...payload.listings, ...pool].find((listing) => listing.id === detailId) ?? null;

  function chooseDeal(next: DealFilter) {
    const resolved: DealFilter = deal === next ? "all" : next;
    setDeal(resolved);
    // Fix: a leftover price preset of the other deal type used to keep filtering silently.
    if (price.type && price.type !== resolved) setPriceId("any");
    setPanel(null);
  }

  function choosePrice(id: string) {
    const next = presetById(PRICE_PRESETS, id);
    setPriceId(id);
    if (next.type) setDeal(next.type);
    setPanel(null);
  }

  const countLabel =
    visible.length === 1 ? "1 home" : `${visible.length} homes`;

  return (
    <main className="flex h-dvh flex-col bg-paper text-ink">
      <header className="z-20 shrink-0 border-b border-line bg-paper">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-3 px-4 py-3 md:px-6">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span className="grid size-10 place-items-center rounded-full bg-grove text-on-grove" aria-hidden="true">
                <Leaf className="size-5" strokeWidth={1.75} />
              </span>
              <div>
                <p className="font-display text-2xl leading-none">Linden</p>
                <p className="text-xs text-muted">Listings, gathered</p>
              </div>
            </div>
            <div className="flex items-center gap-2 md:hidden">
              <PaneButton active={mobilePane === "list"} onClick={() => setMobilePane("list")} label="List">
                <Rows3 className="size-4" aria-hidden="true" />
              </PaneButton>
              <PaneButton active={mobilePane === "map"} onClick={() => setMobilePane("map")} label="Map">
                <MapIcon className="size-4" aria-hidden="true" />
              </PaneButton>
            </div>
          </div>

          <form
            role="search"
            className="relative"
            onSubmit={(event) => {
              event.preventDefault();
              void runSearch();
            }}
          >
            <Search className="pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted" aria-hidden="true" />
            <input
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="City, neighborhood, or address"
              aria-label="Search listings"
              className="h-12 w-full rounded-full bg-card pr-12 pl-11 text-base shadow-card outline-none placeholder:text-muted focus-visible:ring-2 focus-visible:ring-grove"
            />
            {draft ? (
              <button
                type="button"
                aria-label="Clear search"
                onClick={() => {
                  setDraft("");
                  setLocation("");
                  setPlace(null);
                  setPlaceMsg("");
                }}
                className="absolute top-1/2 right-1.5 grid size-9 -translate-y-1/2 place-items-center rounded-full text-muted"
              >
                <X className="size-4" />
              </button>
            ) : null}
          </form>

          <div className="chip-row -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 md:mx-0 md:px-0">
            <Chip active={false} onClick={() => setFormOpen(true)}>
              <Plus className="size-3.5" aria-hidden="true" />
              Post
            </Chip>
            <Chip active={deal === "rent"} onClick={() => chooseDeal("rent")}>
              Rent
            </Chip>
            <Chip active={deal === "sale"} onClick={() => chooseDeal("sale")}>
              Sale
            </Chip>
            <Chip
              active={area.id !== "any" || panel === "area"}
              onClick={() => setPanel((current) => (current === "area" ? null : "area"))}
            >
              <SlidersHorizontal className="size-3.5" aria-hidden="true" />
              {area.short}
            </Chip>
            <Chip
              active={price.id !== "any" || panel === "price"}
              onClick={() => setPanel((current) => (current === "price" ? null : "price"))}
            >
              {price.short}
            </Chip>
            <Chip active={savedOnly} onClick={() => setSavedOnly((current) => !current)}>
              <Heart className={savedOnly ? "size-3.5 fill-current" : "size-3.5"} aria-hidden="true" />
              Saved
              <span className="tabular-nums">{savedIds.length}</span>
            </Chip>
          </div>

          {panel ? (
            <div className="flex flex-wrap gap-2" role="group" aria-label={panel === "price" ? "Price" : "Area"}>
              {(panel === "price" ? PRICE_PRESETS : AREA_PRESETS).map((option) => {
                const active = panel === "price" ? option.id === priceId : option.id === areaId;
                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => (panel === "price" ? choosePrice(option.id) : (setAreaId(option.id), setPanel(null)))}
                    className={
                      "min-h-11 rounded-full px-4 text-sm " +
                      (active ? "bg-grove text-on-grove" : "bg-card text-ink shadow-card")
                    }
                  >
                    {option.label}
                  </button>
                );
              })}
            </div>
          ) : null}

          {place ? (
            <p className="flex items-start gap-2 text-sm">
              <MapPin className="mt-0.5 size-4 shrink-0 text-grove" aria-hidden="true" />
              <span className="text-pretty">
                Showing homes near <b className="font-medium">{place.label}</b>
              </span>
            </p>
          ) : placeMsg ? (
            <p className="text-sm text-muted">{placeMsg}</p>
          ) : null}

          <p className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1 text-sm">
            <span className="font-medium tabular-nums" aria-live="polite">
              {searching ? "Searching…" : countLabel}
            </span>
            <span className="text-pretty text-muted">
              Example homes. Source links open that city’s live search.
            </span>
          </p>
        </div>
      </header>

      <div className="mx-auto flex min-h-0 w-full max-w-7xl flex-1">
        <section
          className={
            "min-h-0 flex-1 overflow-y-auto px-4 py-4 md:px-6 " + (mobilePane === "map" ? "hidden md:block" : "")
          }
          aria-label="Listings"
        >
          {visible.length === 0 ? (
            <Empty
              title={savedOnly ? "Nothing saved in this search" : "No homes match"}
              body={
                savedOnly
                  ? "Hearts stay on this device. Save a card, or clear filters to see them."
                  : "Try Austin, Miami, Portland, Denver, Seattle, Chicago, Brooklyn, or Tiburon."
              }
            />
          ) : (
            <ul className="grid gap-4 pb-8 md:grid-cols-2">
              {visible.map((listing) => (
                <li key={listing.id}>
                  <PropertyCard
                    listing={listing}
                    selected={listing.id === selectedId}
                    saved={savedIds.includes(listing.id)}
                    onOpen={() => {
                      setSelectedId(listing.id);
                      setDetailId(listing.id);
                    }}
                    onSave={() => toggleSaved(listing.id)}
                  />
                </li>
              ))}
            </ul>
          )}
        </section>

        <aside
          className={
            "min-h-0 w-full border-line md:block md:w-[42%] md:border-l " +
            (mobilePane === "map" ? "block" : "hidden")
          }
          aria-label="Map"
        >
          <ListingMap
            listings={visible}
            place={place}
            selectedId={selectedId}
            active={mobilePane === "map"}
            onSelect={(id) => {
              setSelectedId(id);
              setDetailId(id);
            }}
          />
        </aside>
      </div>

      <PostForm open={formOpen} onClose={() => setFormOpen(false)} />

      <ListingDetail
        listing={detail}
        saved={detail ? savedIds.includes(detail.id) : false}
        onSave={() => detail && toggleSaved(detail.id)}
        onClose={() => setDetailId(null)}
        onDelete={
          detail?.mine
            ? () => {
                removePost(detail.id);
                setDetailId(null);
              }
            : undefined
        }
      />
    </main>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={
        "inline-flex min-h-11 shrink-0 items-center gap-1.5 rounded-full px-4 text-sm font-medium " +
        (active ? "bg-grove text-on-grove" : "bg-card text-ink shadow-card")
      }
    >
      {children}
    </button>
  );
}

function PaneButton({
  active,
  onClick,
  label,
  children,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={
        "inline-flex min-h-11 items-center gap-1.5 rounded-full px-3 text-sm font-medium " +
        (active ? "bg-grove text-on-grove" : "bg-card text-ink shadow-card")
      }
    >
      {children}
      {label}
    </button>
  );
}

function Empty({ title, body }: { title: string; body: string }) {
  return (
    <div className="mx-auto flex max-w-sm flex-col gap-2 py-16 text-center">
      <h2 className="font-display text-2xl">{title}</h2>
      <p className="text-pretty text-sm text-muted">{body}</p>
    </div>
  );
}
