import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Listing } from "./listings";

/** Posts are saved on this device (localStorage). */
type PostsState = {
  posts: Listing[];
  add: (post: Listing) => void;
  remove: (id: string) => void;
};

export const usePosts = create<PostsState>()(
  persist(
    (set) => ({
      posts: [],
      add: (post) => set((s) => ({ posts: [post, ...s.posts] })),
      remove: (id) => set((s) => ({ posts: s.posts.filter((p) => p.id !== id) })),
    }),
    { name: "linden-posts" },
  ),
);
