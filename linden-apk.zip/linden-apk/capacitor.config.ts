import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.earningtips.linden", // Play Store se pehle apna final ID yahan set karein
  appName: "Linden",
  webDir: "dist",
};

export default config;
