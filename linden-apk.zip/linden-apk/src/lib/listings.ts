/**
 * Linden's listing board.
 *
 * Homes are example records (fictional addresses in real neighborhoods).
 * Filtering runs on-device so the app works offline.
 */

export type DealType = "rent" | "sale";

export type Listing = {
  id: string;
  title: string;
  price: number;
  type: DealType;
  address: string;
  neighborhood: string;
  city: string;
  region: string;
  beds: number;
  baths: number;
  areaSqft: number;
  lat: number;
  lng: number;
  image: string;
  source: string;
  sourceUrl: string;
  blurb: string;
};

export type PropertyQuery = {
  location?: string;
  type?: DealType | "";
  priceMin?: number;
  priceMax?: number;
  areaMin?: number;
  areaMax?: number;
};

export type PropertiesPayload = {
  count: number;
  listings: Listing[];
  cache: { hit: boolean; ttlHours: number };
};

export const CACHE_TTL_HOURS = 24;

const LISTINGS: Listing[] = [
  {
    id: "westlake-pavilion",
    title: "Timber pavilion under the trees",
    price: 1_875_000,
    type: "sale",
    address: "14 Rollingwood Cove",
    neighborhood: "West Lake Hills",
    city: "Austin",
    region: "TX",
    beds: 4,
    baths: 3,
    areaSqft: 2680,
    lat: 30.2952,
    lng: -97.7868,
    image: "/listings/austin-modern.jpg",
    source: "Zillow",
    sourceUrl: "https://www.zillow.com/west-lake-hills-tx/",
    blurb:
      "Black steel, warm timber, and a glass wall that opens the dining room onto a covered terrace. The lawn stays deep and shaded.",
  },
  {
    id: "east-austin-plants",
    title: "Plant-filled one-bedroom",
    price: 2450,
    type: "rent",
    address: "908 Canopy Lane, Apt 2",
    neighborhood: "East Cesar Chavez",
    city: "Austin",
    region: "TX",
    beds: 1,
    baths: 1,
    areaSqft: 740,
    lat: 30.2598,
    lng: -97.7244,
    image: "/listings/austin-loft.jpg",
    source: "Zillow",
    sourceUrl: "https://www.zillow.com/austin-tx/rentals/",
    blurb:
      "A bright front room with oak floors, built-in books, and enough light for a small jungle. Quiet street, walkable coffee.",
  },
  {
    id: "hill-country-white",
    title: "White house on the hill",
    price: 2_150_000,
    type: "sale",
    address: "3 Ledge Court",
    neighborhood: "West Lake Hills",
    city: "Austin",
    region: "TX",
    beds: 4,
    baths: 3,
    areaSqft: 3100,
    lat: 30.3074,
    lng: -97.8216,
    image: "/listings/miami-brickell.jpg",
    source: "Redfin",
    sourceUrl: "https://www.redfin.com/city/30749/TX/Austin",
    blurb:
      "A crisp white volume with a plunge pool, stone accent walls, and a covered lounge that stays usable in August.",
  },
  {
    id: "barton-stair",
    title: "Open stair and a pool court",
    price: 1_540_000,
    type: "sale",
    address: "221 Barton Shade",
    neighborhood: "Barton Hills",
    city: "Austin",
    region: "TX",
    beds: 3,
    baths: 2.5,
    areaSqft: 1980,
    lat: 30.2524,
    lng: -97.7862,
    image: "/listings/sf-hill.jpg",
    source: "Compass",
    sourceUrl: "https://www.compass.com/homes-for-sale/austin-tx/",
    blurb:
      "A long living room, a floating oak stair, and glass that looks straight onto the pool deck. Easy weekends, serious light.",
  },
  {
    id: "grove-verandah",
    title: "Verandah house with a lap pool",
    price: 2_640_000,
    type: "sale",
    address: "48 Leaf Street",
    neighborhood: "Coconut Grove",
    city: "Miami",
    region: "FL",
    beds: 4,
    baths: 3,
    areaSqft: 2920,
    lat: 25.7276,
    lng: -80.2438,
    image: "/listings/brooklyn-brown.jpg",
    source: "Compass",
    sourceUrl: "https://www.compass.com/homes-for-sale/coconut-grove-miami-fl/",
    blurb:
      "A white two-story with a deep verandah, a new wood wing, and a pool that takes the whole back garden.",
  },
  {
    id: "grove-soffit",
    title: "White volume, wood soffit",
    price: 3_480_000,
    type: "sale",
    address: "9 Bay Cedar",
    neighborhood: "Coconut Grove",
    city: "Miami",
    region: "FL",
    beds: 4,
    baths: 4,
    areaSqft: 3450,
    lat: 25.7342,
    lng: -80.2365,
    image: "/listings/miami-grove.jpg",
    source: "Zillow",
    sourceUrl: "https://www.zillow.com/coconut-grove-miami-fl/",
    blurb:
      "Stacked terraces, a warm wood ceiling, and sliding walls that erase the line between the hall and the pool.",
  },
  {
    id: "design-pool-villa",
    title: "Rooftop pool villa",
    price: 4_250_000,
    type: "sale",
    address: "700 Isle Drive",
    neighborhood: "Mid-Beach",
    city: "Miami",
    region: "FL",
    beds: 5,
    baths: 4,
    areaSqft: 4100,
    lat: 25.8124,
    lng: -80.1236,
    image: "/listings/denver-modern.jpg",
    source: "Redfin",
    sourceUrl: "https://www.redfin.com/city/11458/FL/Miami",
    blurb:
      "Glass rails, a roof terrace, and a pool that sits level with the piano nobile. Built for full sun.",
  },
  {
    id: "irvington-porch",
    title: "Shingle house with a long porch",
    price: 925_000,
    type: "sale",
    address: "16 Hazel Knott",
    neighborhood: "Irvington",
    city: "Portland",
    region: "OR",
    beds: 4,
    baths: 2,
    areaSqft: 2140,
    lat: 45.5418,
    lng: -122.6482,
    image: "/listings/portland-craft.jpg",
    source: "Realtor",
    sourceUrl: "https://www.realtor.com/realestateandhomes-search/Portland_OR",
    blurb:
      "Cedar shingles, a white porch, and a lawn that actually gets used. The kind of street people stay on.",
  },
  {
    id: "sandy-lodge",
    title: "Log house among the firs",
    price: 689_000,
    type: "sale",
    address: "4 Fir Switch",
    neighborhood: "Sandy",
    city: "Sandy",
    region: "OR",
    beds: 3,
    baths: 2,
    areaSqft: 1640,
    lat: 45.3974,
    lng: -122.261,
    image: "/listings/portland-rent.jpg",
    source: "Zillow",
    sourceUrl: "https://www.zillow.com/sandy-or/",
    blurb:
      "A steep gable, morning light through the firs, and a quiet road. Forty minutes from the city when you want it.",
  },
  {
    id: "highlands-herringbone",
    title: "Herringbone one-bedroom",
    price: 2350,
    type: "rent",
    address: "512 Pony House, Apt 4",
    neighborhood: "Highlands",
    city: "Denver",
    region: "CO",
    beds: 1,
    baths: 1,
    areaSqft: 780,
    lat: 39.7612,
    lng: -105.0118,
    image: "/listings/denver-rino.jpg",
    source: "Zillow",
    sourceUrl: "https://www.zillow.com/denver-co/rentals/",
    blurb:
      "Herringbone oak, a long white cabinet, and a window that faces the quiet side of the block. One bedroom, done properly.",
  },
  {
    id: "evergreen-chalet",
    title: "Stone-chimney chalet",
    price: 1_180_000,
    type: "sale",
    address: "88 Switchback",
    neighborhood: "Evergreen",
    city: "Evergreen",
    region: "CO",
    beds: 4,
    baths: 3,
    areaSqft: 2460,
    lat: 39.6333,
    lng: -105.3172,
    image: "/listings/chicago-grey.jpg",
    source: "Redfin",
    sourceUrl: "https://www.redfin.com/city/6169/CO/Evergreen",
    blurb:
      "A steep roof, a stone chimney, and glass that looks into the trees. Evenings here feel like a lodge you actually own.",
  },
  {
    id: "queen-anne-fire",
    title: "Fireplace condo with a view",
    price: 3850,
    type: "rent",
    address: "1900 Queen Anne Ave, Apt 6",
    neighborhood: "Queen Anne",
    city: "Seattle",
    region: "WA",
    beds: 2,
    baths: 2,
    areaSqft: 1180,
    lat: 47.6372,
    lng: -122.357,
    image: "/listings/brooklyn-apt.jpg",
    source: "Zillow",
    sourceUrl: "https://www.zillow.com/seattle-wa/rentals/",
    blurb:
      "Corner glass, a working fireplace, and a balcony over the trees. Two bedrooms, carpeted, and unusually calm.",
  },
  {
    id: "streeterville-high",
    title: "High-floor living room",
    price: 4100,
    type: "rent",
    address: "400 Lake Shore, Apt 32",
    neighborhood: "Streeterville",
    city: "Chicago",
    region: "IL",
    beds: 2,
    baths: 2,
    areaSqft: 1320,
    lat: 41.8924,
    lng: -87.6184,
    image: "/listings/chicago-loft.jpg",
    source: "Zillow",
    sourceUrl: "https://www.zillow.com/chicago-il/rentals/",
    blurb:
      "Tall windows over the lake edge of downtown, a leather sofa length, and room to actually have people over.",
  },
  {
    id: "williamsburg-books",
    title: "Book-lined one-bedroom",
    price: 3650,
    type: "rent",
    address: "77 North 7th, Apt 3",
    neighborhood: "Williamsburg",
    city: "Brooklyn",
    region: "NY",
    beds: 1,
    baths: 1,
    areaSqft: 690,
    lat: 40.7182,
    lng: -73.9576,
    image: "/listings/seattle-hill.jpg",
    source: "StreetEasy",
    sourceUrl: "https://streeteasy.com/for-rent/williamsburg",
    blurb:
      "White built-ins, a record shelf, and plants that have clearly been here a while. A true one-bedroom, not a flex.",
  },
  {
    id: "tiburon-spa",
    title: "Stucco villa with a spa",
    price: 3_950_000,
    type: "sale",
    address: "2 Belvedere Grade",
    neighborhood: "Tiburon",
    city: "Tiburon",
    region: "CA",
    beds: 5,
    baths: 4,
    areaSqft: 4200,
    lat: 37.8735,
    lng: -122.4567,
    image: "/listings/sf-victorian.jpg",
    source: "Compass",
    sourceUrl: "https://www.compass.com/homes-for-sale/tiburon-ca/",
    blurb:
      "Warm stucco, a spiral to the upper loggia, and a spa set into the terrace. Sunset hits the arches first.",
  },
];

export function queryListings(query: PropertyQuery): Listing[] {
  const location = (query.location ?? "").trim().toLowerCase();
  return LISTINGS.filter((listing) => {
    if (query.type && listing.type !== query.type) return false;
    if (query.priceMin != null && listing.price < query.priceMin) return false;
    if (query.priceMax != null && listing.price > query.priceMax) return false;
    if (query.areaMin != null && listing.areaSqft < query.areaMin) return false;
    if (query.areaMax != null && listing.areaSqft > query.areaMax) return false;
    if (!location) return true;
    const haystack = [
      listing.title,
      listing.address,
      listing.neighborhood,
      listing.city,
      listing.region,
      listing.type,
    ]
      .join(" ")
      .toLowerCase();
    return haystack.includes(location);
  });
}

export function toPayload(listings: Listing[], hit: boolean): PropertiesPayload {
  return {
    count: listings.length,
    listings,
    cache: { hit, ttlHours: CACHE_TTL_HOURS },
  };
}

export function formatPrice(listing: Listing): string {
  if (listing.type === "rent") {
    return `$${listing.price.toLocaleString("en-US")}/mo`;
  }
  if (listing.price >= 1_000_000) {
    const millions = listing.price / 1_000_000;
    const digits = millions >= 10 ? 1 : 2;
    return `$${millions.toFixed(digits)}M`;
  }
  return `$${listing.price.toLocaleString("en-US")}`;
}

export function formatPriceShort(listing: Listing): string {
  if (listing.type === "rent") {
    const thousands = listing.price / 1000;
    return `$${thousands.toFixed(1)}k`;
  }
  if (listing.price >= 1_000_000) {
    return `$${(listing.price / 1_000_000).toFixed(1)}M`;
  }
  return `$${Math.round(listing.price / 1000)}k`;
}

export function formatBaths(baths: number): string {
  return Number.isInteger(baths) ? String(baths) : baths.toFixed(1);
}

export function placeLine(listing: Listing): string {
  return `${listing.neighborhood}, ${listing.city}`;
}
