import type { DealType } from "@/lib/listings";

export type PricePreset = {
  id: string;
  label: string;
  short: string;
  type: DealType | null;
  min?: number;
  max?: number;
};

export type AreaPreset = {
  id: string;
  label: string;
  short: string;
  min?: number;
  max?: number;
};

export const PRICE_PRESETS: PricePreset[] = [
  { id: "any", label: "Any price", short: "Price", type: null },
  { id: "sale-u750", label: "Under $750k", short: "Under $750k", type: "sale", max: 750_000 },
  {
    id: "sale-mid",
    label: "$750k – $1.5M",
    short: "$750k–$1.5M",
    type: "sale",
    min: 750_000,
    max: 1_500_000,
  },
  {
    id: "sale-high",
    label: "$1.5M – $3M",
    short: "$1.5M–$3M",
    type: "sale",
    min: 1_500_000,
    max: 3_000_000,
  },
  { id: "sale-top", label: "$3M and up", short: "$3M+", type: "sale", min: 3_000_000 },
  { id: "rent-u3", label: "Under $3,000 / mo", short: "Under $3k", type: "rent", max: 3_000 },
  {
    id: "rent-mid",
    label: "$3,000 – $4,000 / mo",
    short: "$3k–$4k",
    type: "rent",
    min: 3_000,
    max: 4_000,
  },
  { id: "rent-top", label: "$4,000 / mo and up", short: "$4k+", type: "rent", min: 4_000 },
];

export const AREA_PRESETS: AreaPreset[] = [
  { id: "any", label: "Any size", short: "Area" },
  { id: "s", label: "Under 1,000 sq ft", short: "Under 1,000", max: 1_000 },
  { id: "m", label: "1,000 – 2,000 sq ft", short: "1–2k sq ft", min: 1_000, max: 2_000 },
  { id: "l", label: "2,000 – 3,000 sq ft", short: "2–3k sq ft", min: 2_000, max: 3_000 },
  { id: "xl", label: "3,000 sq ft and up", short: "3,000+", min: 3_000 },
];

export function presetById<T extends { id: string }>(presets: T[], id: string): T {
  return presets.find((preset) => preset.id === id) ?? presets[0];
}
