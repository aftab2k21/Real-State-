import { create } from "zustand";
import { persist } from "zustand/middleware";

/**
 * Saved homes live in this browser only (localStorage via Zustand persist).
 * Nothing is sent to an account — there isn't one.
 */
type FavoritesState = {
  ids: string[];
  toggle: (id: string) => void;
};

export const useFavorites = create<FavoritesState>()(
  persist(
    (set, get) => ({
      ids: [],
      toggle: (id) => {
        const ids = get().ids;
        set({
          ids: ids.includes(id) ? ids.filter((item) => item !== id) : [...ids, id],
        });
      },
    }),
    { name: "linden-favorites" },
  ),
);
