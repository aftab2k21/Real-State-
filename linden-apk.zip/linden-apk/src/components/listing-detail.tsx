import * as Dialog from "@radix-ui/react-dialog";
import { ArrowUpRight, Heart, MapPin, X } from "lucide-react";
import { formatBaths, formatPrice, placeLine, type Listing } from "@/lib/listings";

type Props = {
  listing: Listing | null;
  saved: boolean;
  onSave: () => void;
  onClose: () => void;
};

export function ListingDetail({ listing, saved, onSave, onClose }: Props) {
  return (
    <Dialog.Root open={listing != null} onOpenChange={(open) => !open && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/45" />
        <Dialog.Content className="fixed inset-x-0 bottom-0 z-50 max-h-[92dvh] overflow-y-auto rounded-t-3xl bg-card shadow-card focus:outline-none md:inset-auto md:top-1/2 md:left-1/2 md:w-[min(40rem,calc(100%-2rem))] md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-3xl">
          {listing ? (
            <div>
              <div className="relative">
                <img
                  src={listing.image}
                  alt=""
                  className="aspect-3/2 w-full object-cover outline outline-1 -outline-offset-1 outline-ink/10 md:rounded-t-3xl"
                />
                <Dialog.Close
                  aria-label="Close"
                  className="absolute top-3 right-3 grid size-11 place-items-center rounded-full bg-card shadow-card"
                >
                  <X className="size-5" strokeWidth={1.75} />
                </Dialog.Close>
              </div>
              <div className="flex flex-col gap-4 p-5">
                <div className="flex flex-col gap-1">
                  <p className="text-xs font-medium tracking-wide text-grove uppercase">
                    {listing.type === "rent" ? "For rent" : "For sale"} · {listing.source}
                  </p>
                  <Dialog.Title className="font-display text-3xl leading-tight text-ink">
                    {listing.title}
                  </Dialog.Title>
                  <Dialog.Description className="text-pretty text-muted">{listing.blurb}</Dialog.Description>
                </div>
                <p className="font-display text-3xl text-ink tabular-nums">{formatPrice(listing)}</p>
                <p className="flex items-start gap-2 text-sm text-ink">
                  <MapPin className="mt-0.5 size-4 shrink-0 text-grove" aria-hidden="true" />
                  <span>
                    {listing.address}
                    <span className="block text-muted">
                      {placeLine(listing)}, {listing.region}
                    </span>
                  </span>
                </p>
                <dl className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-xl bg-grove-soft px-2 py-3">
                    <dt className="text-xs text-muted">Beds</dt>
                    <dd className="font-display text-xl tabular-nums">{listing.beds}</dd>
                  </div>
                  <div className="rounded-xl bg-grove-soft px-2 py-3">
                    <dt className="text-xs text-muted">Baths</dt>
                    <dd className="font-display text-xl tabular-nums">{formatBaths(listing.baths)}</dd>
                  </div>
                  <div className="rounded-xl bg-grove-soft px-2 py-3">
                    <dt className="text-xs text-muted">Area</dt>
                    <dd className="font-display text-xl tabular-nums">
                      {listing.areaSqft.toLocaleString("en-US")}
                    </dd>
                  </div>
                </dl>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <a
                    href={listing.sourceUrl}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-full bg-grove px-4 text-sm font-medium text-on-grove hover:bg-grove-deep"
                  >
                    View original listing
                    <ArrowUpRight className="size-4" aria-hidden="true" />
                  </a>
                  <button
                    type="button"
                    onClick={onSave}
                    aria-pressed={saved}
                    className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-paper px-4 text-sm font-medium text-ink"
                  >
                    <Heart
                      className={saved ? "size-4 fill-grove text-grove" : "size-4"}
                      aria-hidden="true"
                    />
                    {saved ? "Saved" : "Save"}
                  </button>
                </div>
                <p className="text-xs text-pretty text-muted">
                  Example home. The source button opens that city’s live search on {listing.source}, not a
                  contract for this address.
                </p>
              </div>
            </div>
          ) : null}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
