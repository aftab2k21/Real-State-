import { useEffect, useRef, useState } from "react";
import type { Map as LeafletMap, LayerGroup } from "leaflet";
import "leaflet/dist/leaflet.css";
import { formatPriceShort, type Listing } from "@/lib/listings";

type Props = {
  listings: Listing[];
  selectedId: string | null;
  active: boolean;
  onSelect: (id: string) => void;
};

function asLeaflet(mod: typeof import("leaflet")) {
  const withDefault = mod as typeof import("leaflet") & { default?: typeof import("leaflet") };
  return withDefault.default?.map ? withDefault.default : mod;
}

export function ListingMap({ listings, selectedId, active, onSelect }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const groupRef = useRef<LayerGroup | null>(null);
  const onSelectRef = useRef(onSelect);
  const fittedRef = useRef("");
  const [ready, setReady] = useState(false);

  onSelectRef.current = onSelect;

  useEffect(() => {
    let cancelled = false;
    const host = hostRef.current;
    if (!host) return;

    void (async () => {
      const L = asLeaflet(await import("leaflet"));
      if (cancelled || mapRef.current) return;
      const map = L.map(host, { zoomControl: false, scrollWheelZoom: true }).setView([39.5, -98.35], 4);
      L.tileLayer(import.meta.env.VITE_TILE_URL || "https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 18,
      }).addTo(map);
      L.control.zoom({ position: "bottomright" }).addTo(map);
      groupRef.current = L.layerGroup().addTo(map);
      mapRef.current = map;
      setReady(true);
    })();

    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
      groupRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const map = mapRef.current;
    const group = groupRef.current;
    if (!map || !group) return;
    let cancelled = false;

    void (async () => {
      const L = asLeaflet(await import("leaflet"));
      if (cancelled) return;
      group.clearLayers();
      const points: [number, number][] = [];
      for (const listing of listings) {
        points.push([listing.lat, listing.lng]);
        const selected = listing.id === selectedId;
        const icon = L.divIcon({
          className: "linden-pin-wrap",
          html: `<span class="linden-pin${selected ? " is-selected" : ""}">${formatPriceShort(listing)}</span>`,
          iconSize: [76, 32],
          iconAnchor: [38, 32],
        });
        const marker = L.marker([listing.lat, listing.lng], {
          icon,
          zIndexOffset: selected ? 800 : 0,
          keyboard: true,
          title: listing.title,
        });
        marker.on("click", () => onSelectRef.current(listing.id));
        marker.addTo(group);
      }

      const signature = listings.map((listing) => listing.id).join("|");
      if (fittedRef.current !== signature) {
        fittedRef.current = signature;
        if (points.length === 1) map.setView(points[0], 12, { animate: false });
        else if (points.length > 1) {
          map.fitBounds(L.latLngBounds(points), { padding: [40, 40], maxZoom: 11, animate: false });
        } else {
          map.setView([39.5, -98.35], 4, { animate: false });
        }
      }
      map.invalidateSize();
    })();

    return () => {
      cancelled = true;
    };
  }, [listings, selectedId, ready]);

  useEffect(() => {
    if (!ready || !active) return;
    const frame = requestAnimationFrame(() => mapRef.current?.invalidateSize());
    return () => cancelAnimationFrame(frame);
  }, [active, ready, listings.length]);

  return (
    <div className="relative z-0 h-full min-h-80">
      <div ref={hostRef} className="h-full w-full" />
    </div>
  );
}
